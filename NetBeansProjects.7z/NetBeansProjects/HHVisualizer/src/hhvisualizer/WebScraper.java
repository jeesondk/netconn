/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hhvisualizer;

import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Base64;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import java.util.Properties;

/**
 *
 * @author jes
 */
public class WebScraper {
    
    private boolean proxyEnabled;
    private Proxy proxy;
    private Properties prop;
    
    public WebScraper(){
        Initialize();
    }
    
    private void Initialize(){
        prop = new Properties();
        this.proxyEnabled = prop
    }
    
    public Object GetData(String endPoint) throws IOException{
        //Mangler proxy handler ud fra properties fil
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("10.255.0.26", 8080));

                //skal hentes fra en liste af endpoints
		String _url = "http://jeeson3k.ddns.net/"; 
		
                //skal wrappes pænt
		URL url = new URL(_url);
		URLConnection con = url.openConnection(proxy);
		String userpass = "pvserver" + ":" + "pvwr";
		String basicAuth = "Basic " + new String(Base64.getEncoder().encode(userpass.getBytes()));
		con.setRequestProperty ("Authorization", basicAuth);

		
		
		InputStream in = con.getInputStream();
		String encoding = con.getContentEncoding();
		encoding = encoding == null ? "UTF-8" : encoding;
	
		Document doc = null;
		try{
		doc= Jsoup.parse(in, "UTF-8", _url);
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		Elements tables = doc.select("table");
		
		
		ArrayList<String[][]> tableArr = new ArrayList<String[][]>();
		for (Element table : tables) {
		    Elements trs = table.select("tr");
		    String[][] trtd = new String[trs.size()][];
		    for (int i = 0; i < trs.size(); i++) {
		        Elements tds = trs.get(i).select("td");
		        trtd[i] = new String[tds.size()];
		        for (int j = 0; j < tds.size(); j++) {
		            trtd[i][j] = tds.get(j).text(); 
		        }
		    }
		    tableArr.add(trtd);
		}
		
		String[][] curVals = tableArr.get(2);
                return curVals;
                
//		System.out.println("Summary values:");
//		System.out.println(curVals[3][1] + ": " + curVals[3][2] + curVals[3][3]);
//		System.out.println(curVals[3][4] + ": " + curVals[3][5] + curVals[3][6]);
//		System.out.println(curVals[5][4] + ": " + curVals[5][5] + curVals[5][6]);
//		System.out.println("");
//		System.out.println("DC Details:");
//		System.out.println(curVals[14][1] + ": " + curVals[15][1] + " = " + curVals[15][2] + curVals[15][3] + ", "  + curVals[17][1] + " = " + curVals[17][2] + curVals[17][3]);
//		System.out.println(curVals[19][1] + ": " + curVals[20][1] + " = " + curVals[20][2] + curVals[20][3] + ", "  + curVals[22][1] + " = " + curVals[22][2] + curVals[22][3]);
//		System.out.println(curVals[24][1] + ": " + curVals[25][1] + " = " + curVals[25][2] + curVals[25][3] + ", "  + curVals[27][1] + " = " + curVals[27][2] + curVals[27][3]);
//		
//		System.out.println("");
//		
//		System.out.println("AC Details:");
//		System.out.println(curVals[14][4] + ": " + curVals[15][4] + " = " + curVals[15][5] + curVals[15][6] + ", "  + curVals[17][4] + " = " + curVals[17][5] + curVals[17][6]); 
//		System.out.println(curVals[19][4] + ": " + curVals[20][4] + " = " + curVals[20][5] + curVals[20][6] + ", "  + curVals[22][4] + " = " + curVals[22][5] + curVals[22][6]);
//		System.out.println(curVals[24][4] + ": " + curVals[25][4] + " = " + curVals[25][5] + curVals[25][6] + ", "  + curVals[27][4] + " = " + curVals[27][5] + curVals[27][6]);

    }
    
}
