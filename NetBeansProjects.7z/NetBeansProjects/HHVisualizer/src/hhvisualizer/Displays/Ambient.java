package hhvisualizer.Displays;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;


/**
 *
 * @author jes
 */
public class Ambient {
    public JPanel Show(Object dataSource){
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();

        //Create JPanel and add to FrameCurrent
        JPanel panel = new JPanel();
        panel.setLayout(gridbag);
        
        JLabel Text = new JLabel();
        JLabel Value = new JLabel();
        
        //Set size and Add Label
        Text.setFont(new java.awt.Font("Arial Black", 0, 128));
        Value.setFont(new java.awt.Font("Arial Black", 0, 128));
        gridbag.setConstraints(Text, gbc);
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        
        gridbag.setConstraints(Value, gbc);

        Text.setText("Solceller nu");
        Value.setText(dataSource.get(0)[0] + " " + dataSource.get(0)[1]);
        
        panel.add(Text, gbc);
        panel.add(Value, gbc);

        return panel;
    }
}
