/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hhvisualizer.Displays;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.math.BigDecimal;
import javax.swing.JLabel;
import javax.swing.JPanel;
/**
 *
 * @author jes
 */
public class Co2 {
    public JPanel Show(Object dataSource){
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints gbc = new GridBagConstraints();

        //Create JPanel and add to Frame
        JPanel panel = new JPanel();
        panel.setLayout(gridbag);
        
        JLabel Text = new JLabel();
        JLabel Value = new JLabel();
        
        //Set size and Add Label
        Text.setFont(new java.awt.Font("Arial Black", 0, 128));
        Value.setFont(new java.awt.Font("Arial Black", 0, 128));
        
        gridbag.setConstraints(Text, gbc);
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        
        gridbag.setConstraints(Value, gbc);

        Text.setText("CO2 Besparelse");
        Value.setText(calcCO2(dataSource.get(2)[0]) + " " + "ton");

        panel.add(Text, gbc);
        panel.add(Value, gbc);

        return panel;
        
    }
    private BigDecimal calcCO2(String total){
	   BigDecimal production = new BigDecimal(total);	
	   BigDecimal co2Factor = new BigDecimal(0.0005925);
	   BigDecimal co2Reduct = production.multiply(co2Factor);
    
    return co2Reduct.setScale(3, BigDecimal.ROUND_CEILING);
   }
}
